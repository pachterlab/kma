library(testthat)
library(kma)

test_check("kma")
