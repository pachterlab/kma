# Pre-processing scripts

Below are the scripts used for pre-processing annotation files. They are self
contained, so you can simply call them from this directory. All source with the
excetion of `gtf_parser.py` were written by Harold Pimentel and is released
under the GPLv2 license.

`gtf_parser.py` was written by Riyaz Faizullabhoy and can be found at
https://github.com/riyazdf/gtf-parser under the MIT license.
